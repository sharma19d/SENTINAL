import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Shield, ShieldAlert, ShieldCheck, Lock, Gavel, Network, Terminal, Activity, Cpu, Brain, Zap } from 'lucide-react';
import { FIREWALL_RULES } from '../constants';
import { cn } from '../lib/utils';
import { FirewallRule } from '../types';

export default function Firewall() {
  const [rules, setRules] = useState<FirewallRule[]>(FIREWALL_RULES);
  const [autoQuarantine, setAutoQuarantine] = useState(true);

  const toggleRule = (id: string) => {
    setRules(prev => prev.map(r => r.id === id ? { ...r, status: !r.status } : r));
  };

  return (
    <div className="p-10 flex flex-col gap-10">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight">Security Controls & Firewall</h2>
          <p className="text-sm text-outline mt-1 font-sans">Active defensive posture management and eBPF rule configuration.</p>
        </div>
        
        <div className="flex items-center gap-3">
          <motion.div 
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-2.5 h-2.5 rounded-full bg-white glow-white" 
          />
          <span className="text-[11px] font-mono text-white uppercase tracking-widest font-bold">System Armed</span>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-8 items-stretch">
        {/* Main Firewall Table */}
        <div className="col-span-12 lg:col-span-8 flex flex-col gap-8">
          <section className="glass-panel rounded-2xl p-6 flex flex-col">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-white flex items-center gap-3">
                <Shield className="w-5 h-5" />
                Active Firewall Rules
              </h3>
              <div className="text-[10px] font-display font-bold text-outline border border-white/10 px-3 py-1 rounded uppercase tracking-wider">eBPF / NFTABLES</div>
            </div>

            <div className="void-card rounded-xl overflow-hidden flex-1 border border-white/5">
              <table className="w-full text-left border-collapse">
                <thead className="bg-white/5 border-b border-white/5">
                  <tr>
                    <th className="py-4 px-6 text-[10px] font-display font-bold text-outline uppercase tracking-widest">Rule ID</th>
                    <th className="py-4 px-6 text-[10px] font-display font-bold text-outline uppercase tracking-widest">Protocol</th>
                    <th className="py-4 px-6 text-[10px] font-display font-bold text-outline uppercase tracking-widest">Target</th>
                    <th className="py-4 px-6 text-[10px] font-display font-bold text-outline uppercase tracking-widest">Action</th>
                    <th className="py-4 px-6 text-[10px] font-display font-bold text-outline uppercase tracking-widest text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-mono text-xs">
                  {rules.map((rule) => {
                    const isReject = rule.action === 'DROP' || rule.action === 'REJECT';
                    return (
                      <tr 
                        key={rule.id} 
                        className={cn(
                          "transition-colors group",
                          rule.status ? "bg-transparent hover:bg-white/[0.03]" : "bg-black opacity-50"
                        )}
                      >
                        <td className="py-5 px-6 font-bold text-white">{rule.ruleId}</td>
                        <td className="py-5 px-6 text-outline">{rule.protocol}</td>
                        <td className="py-5 px-6 text-outline">{rule.target}</td>
                        <td className="py-5 px-6">
                          <span className={cn(
                            "font-bold",
                            isReject ? "text-on-surface" : rule.action === 'ACCEPT' ? "text-white" : "text-outline"
                          )}>
                            {rule.action}
                          </span>
                        </td>
                        <td className="py-5 px-6">
                          <div className="flex justify-end">
                            <button 
                              onClick={() => toggleRule(rule.id)}
                              className={cn(
                                "w-10 h-5 rounded-full relative transition-all duration-300",
                                rule.status ? "bg-white/20 border border-white" : "bg-white/5 border border-white/10"
                              )}
                            >
                              <div className={cn(
                                "absolute top-0.5 left-0.5 w-3.5 h-3.5 rounded-full transition-all duration-300",
                                rule.status ? "translate-x-5 bg-white glow-white" : "translate-x-0 bg-outline"
                              )} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <div className="p-4 bg-white/[0.02] border-t border-white/5 flex justify-center">
                <button className="text-[10px] font-display font-bold text-outline hover:text-white transition-colors uppercase tracking-[0.2em] py-1">
                  View All Rules (142)
                </button>
              </div>
            </div>
          </section>

          {/* Bottom Row Activity Gauges */}
          <div className="grid grid-cols-3 gap-6">
             <MetricGauge 
               icon={<Cpu className="w-5 h-5 text-outline" />}
               label="Hardware Node (PI 5)"
               value="68"
               unit="% CPU"
               subValue="4.2GB RAM"
               progress={68}
             />
             <MetricGauge 
               icon={<Activity className="w-5 h-5 text-outline" />}
               label="LSTM Inference"
               value="12"
               unit="ms lat."
               isChart
             />
             <MetricGauge 
               icon={<Brain className="w-5 h-5 text-outline" />}
               label="LLM Analysis (Local)"
               value="450"
               unit="ms / req"
               isIdle
             />
          </div>
        </div>

        {/* Side Panel: Policy & Deception */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-8">
          {/* System Policy */}
          <section className="glass-panel-heavy rounded-2xl p-6 relative group overflow-hidden border border-white/10">
            <div className="absolute inset-0 bg-gradient-to-br from-white/[0.03] to-transparent pointer-events-none group-hover:from-white/[0.05] transition-all" />
            
            <h3 className="text-xl font-bold text-white flex items-center gap-3 mb-2 relative z-10">
              <Gavel className="w-5 h-5" />
              System Policy
            </h3>
            <p className="text-xs text-outline mb-6 relative z-10 leading-relaxed">
              Determines appliance response to detected high-confidence threats.
            </p>

            <div className="void-card rounded-xl p-2 flex flex-col gap-2 relative z-10 border border-white/10">
              <button 
                onClick={() => setAutoQuarantine(true)}
                className={cn(
                  "w-full flex items-center justify-between p-4 rounded-lg border transition-all duration-300",
                  autoQuarantine 
                    ? "bg-white/10 border-white text-white glow-white" 
                    : "bg-surface-container-high/40 border-white/5 text-outline hover:border-white/20"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn("w-4 h-4 rounded-full border flex items-center justify-center transition-all", autoQuarantine ? "border-white" : "border-outline")}>
                    {autoQuarantine && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </div>
                  <span className="text-sm font-bold">Auto-Quarantine</span>
                </div>
                <Zap className={cn("w-4 h-4 transition-all", autoQuarantine ? "text-white" : "text-outline/40")} />
              </button>

              <button 
                onClick={() => setAutoQuarantine(false)}
                className={cn(
                  "w-full flex items-center justify-between p-4 rounded-lg border transition-all duration-300",
                  !autoQuarantine 
                    ? "bg-white/10 border-white text-white glow-white" 
                    : "bg-surface-container-high/20 border-white/5 text-outline hover:border-white/20"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn("w-4 h-4 rounded-full border flex items-center justify-center transition-all", !autoQuarantine ? "border-white" : "border-outline")}>
                    {!autoQuarantine && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                  </div>
                  <span className="text-sm font-bold">Manual Approval</span>
                </div>
                <Lock className={cn("w-4 h-4 transition-all", !autoQuarantine ? "text-white" : "text-outline/40")} />
              </button>
            </div>

            <div className="mt-4 flex items-center gap-2 text-white font-display font-bold text-[10px] uppercase tracking-[0.2em] relative z-10 transition-opacity" style={{ opacity: autoQuarantine ? 1 : 0.4 }}>
              <ShieldAlert className="w-3.5 h-3.5" />
              Auto-Quarantine Active
            </div>
          </section>

          {/* Deception Engine */}
          <section className="glass-panel rounded-2xl p-6 flex flex-col flex-1 border border-white/10">
            <h3 className="text-xl font-bold text-white flex items-center gap-3 mb-6">
              <Network className="w-5 h-5 text-outline" />
              Deception Engine
            </h3>

            <div className="space-y-4">
              <DeceptionCard 
                name="Cowrie (SSH/Telnet)"
                ip="10.0.99.2"
                status="ONLINE"
                metrics={[
                  { label: "Connections", value: "42" },
                  { label: "Creds Logged", value: "18", isHighlight: true }
                ]}
                borderColor="border-l-white/60"
              />
              <DeceptionCard 
                name="OpenCanary"
                ip="10.0.99.3"
                status="ONLINE"
                isCanary
                borderColor="border-l-white/20"
              />
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

function MetricGauge({ icon, label, value, unit, subValue, progress, isChart, isIdle }: any) {
  return (
    <div className="glass-panel rounded-xl p-5 flex items-center justify-between group hover:border-white/20 transition-all border border-white/10">
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-full bg-surface-container-highest border border-white/10 flex items-center justify-center transition-all group-hover:border-white/30">
          {icon}
        </div>
        <div>
          <h4 className="text-[9px] font-display font-bold text-outline uppercase tracking-widest">{label}</h4>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="font-mono text-xl text-white font-bold tracking-tight">{value}</span>
            <span className="text-[9px] font-mono text-outline uppercase">{unit}</span>
            {subValue && (
              <>
                <div className="w-px h-3 bg-white/10 mx-1" />
                <span className="font-mono text-xs text-white/70">{subValue.split(' ')[0]}</span>
                <span className="text-[9px] font-mono text-outline uppercase">{subValue.split(' ')[1]}</span>
              </>
            )}
          </div>
        </div>
      </div>
      
      {progress !== undefined && (
        <div className="w-16 h-1.5 bg-black rounded-full overflow-hidden border border-white/5">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className="h-full bg-gradient-to-r from-white/40 to-white glow-white rounded-full"
          />
        </div>
      )}

      {isChart && (
        <div className="w-16 h-8 flex items-end gap-1 opacity-50 overflow-hidden">
          {[0.4, 0.7, 0.5, 0.9, 0.6, 0.8, 0.4, 0.7].map((h, i) => (
             <motion.div 
               key={i}
               animate={{ height: [`${h*100}%`, `${(Math.random()*0.5+0.3)*100}%`, `${h*100}%`] }}
               transition={{ duration: 1.5 + Math.random(), repeat: Infinity }}
               className="w-full bg-white rounded-t-sm"
             />
          ))}
        </div>
      )}

      {isIdle && (
        <span className="text-[9px] font-display font-bold text-white bg-white/10 px-2 py-1 rounded border border-white/30 tracking-[0.2em] uppercase ring-1 ring-white/10">Idle</span>
      )}
    </div>
  );
}

function DeceptionCard({ name, ip, status, metrics, isCanary, borderColor }: any) {
  return (
    <div className={cn(
      "void-card p-4 rounded-xl relative overflow-hidden border-l-2",
      borderColor
    )}>
       <div className="absolute right-[-10px] top-[-10px] opacity-[0.03] select-none">
          <Shield className="w-24 h-24 text-white" />
       </div>
       
       <div className="flex justify-between items-start mb-4 relative z-10">
          <div>
            <h4 className="text-sm font-bold text-white tracking-tight leading-none">{name}</h4>
            <p className="text-[10px] font-mono text-outline uppercase mt-1.5 tracking-wide">vIP: {ip}</p>
          </div>
          <span className="text-[9px] font-display font-bold bg-white/10 text-white px-2 py-1 rounded border border-white/20 ring-1 ring-white/5 uppercase tracking-[0.1em]">{status}</span>
       </div>

       {metrics && (
         <div className="flex items-center gap-6 relative z-10">
           {metrics.map((m: any, i: number) => (
             <React.Fragment key={i}>
                <div className="flex flex-col">
                  <span className="text-[9px] font-display font-bold text-outline uppercase tracking-wider mb-1">{m.label}</span>
                  <span className={cn("text-xl font-mono font-bold tracking-tighter leading-tight", m.isHighlight ? "text-white" : "text-white/60")}>{m.value}</span>
                </div>
                {i < metrics.length - 1 && <div className="h-8 w-px bg-white/10 self-end mb-1" />}
             </React.Fragment>
           ))}
         </div>
       )}

       {isCanary && (
         <div className="relative z-10">
           <p className="text-[9px] font-display font-bold text-outline uppercase tracking-wider mb-2">Active Services:</p>
           <div className="flex gap-2">
             {['SMB', 'HTTP', 'FTP'].map(s => (
               <span key={s} className="bg-white/10 px-2 py-1 rounded border border-white/10 text-[9px] font-mono text-white/70 uppercase tracking-tighter">{s}</span>
             ))}
           </div>
         </div>
       )}
    </div>
  );
}
