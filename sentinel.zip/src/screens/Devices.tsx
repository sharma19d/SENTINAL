import React from 'react';
import { motion } from 'motion/react';
import { Monitor, Camera, Laptop, Router, Search, ShieldAlert, ShieldCheck, Lock, Unlock } from 'lucide-react';
import { DEVICES } from '../constants';
import { cn } from '../lib/utils';
import { Device } from '../types';

export default function Devices() {
  return (
    <div className="p-10 flex flex-col gap-8">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight">Device Registry</h2>
          <p className="text-sm text-outline mt-1">Real-time asset discovery and risk analysis</p>
        </div>
        
        <div className="flex gap-4">
          <div className="void-card rounded-lg px-6 py-4 flex flex-col group transition-all hover:border-white/20">
            <span className="text-[10px] font-display font-bold text-outline uppercase tracking-widest mb-1">Total Devices</span>
            <span className="text-2xl font-mono text-white font-bold leading-none">1,402</span>
          </div>
          <div className="void-card rounded-lg px-6 py-4 flex flex-col border-white/30 glow-white">
            <span className="text-[10px] font-display font-bold text-white uppercase tracking-widest mb-1">Critical Risk</span>
            <span className="text-2xl font-mono text-white font-bold leading-none">14</span>
          </div>
        </div>
      </div>

      <div className="w-full flex-1 min-h-0 flex flex-col">
        {/* Table Headers */}
        <div className="grid grid-cols-[2.5fr_2fr_2fr_1.5fr_1fr] gap-4 px-6 py-3 border-b border-white/5 mb-3">
          <span className="text-[10px] font-display font-bold text-outline uppercase tracking-widest">Asset Identity</span>
          <span className="text-[10px] font-display font-bold text-outline uppercase tracking-widest">Network Locator</span>
          <span className="text-[10px] font-display font-bold text-outline uppercase tracking-widest text-center">Risk Vector</span>
          <span className="text-[10px] font-display font-bold text-outline uppercase tracking-widest text-center">Exposure</span>
          <span className="text-[10px] font-display font-bold text-outline uppercase tracking-widest text-right">Action</span>
        </div>

        {/* Rows */}
        <div className="flex flex-col gap-3">
          {DEVICES.map((device) => (
            <DeviceRow key={device.id} device={device} />
          ))}
        </div>
      </div>
    </div>
  );
}

const DeviceRow: React.FC<{ device: Device }> = ({ device }) => {
  const getIcon = () => {
    switch (device.type) {
      case 'display': return <Monitor className="w-5 h-5" />;
      case 'camera': return <Camera className="w-5 h-5" />;
      case 'laptop': return <Laptop className="w-5 h-5" />;
      case 'router': return <Router className="w-5 h-5" />;
      default: return <Monitor className="w-5 h-5" />;
    }
  };

  const isHighRisk = device.riskScore >= 7;
  const isMediumRisk = device.riskScore >= 4 && device.riskScore < 7;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "grid grid-cols-[2.5fr_2fr_2fr_1.5fr_1fr] gap-4 items-center bg-white/[0.02] border border-white/5 rounded-xl p-3 hover:bg-white/[0.05] transition-all relative overflow-hidden group",
        isHighRisk && "border-white/20"
      )}
    >
      {isHighRisk && <div className="absolute left-0 top-0 bottom-0 w-1 bg-white glow-white" />}
      
      {/* Identity */}
      <div className="flex items-center gap-4 pl-2">
        <div className={cn(
          "w-12 h-12 rounded-lg bg-black border border-white/10 flex items-center justify-center transition-all group-hover:border-white/30",
          isHighRisk ? "text-white" : "text-outline"
        )}>
          {getIcon()}
        </div>
        <div className="flex flex-col min-w-0">
          <span className={cn("text-sm font-bold truncate", isHighRisk ? "text-white" : "text-on-surface")}>{device.name}</span>
          <span className="text-[10px] font-mono text-outline uppercase truncate tracking-tight">OUI: {device.vendor}</span>
        </div>
      </div>

      {/* Network */}
      <div className="flex flex-col">
        <span className="text-sm font-mono text-on-surface leading-tight">{device.ip}</span>
        <span className="text-[10px] font-mono text-outline uppercase tracking-tighter">{device.mac}</span>
      </div>

      {/* Risk Vector */}
      <div className="flex items-center gap-4 px-4">
        <div className={cn(
          "bg-black border border-white/10 w-10 h-10 flex flex-shrink-0 items-center justify-center rounded font-mono font-bold text-sm",
          isHighRisk && "text-white",
          isMediumRisk && "text-white/70",
          !isHighRisk && !isMediumRisk && "text-outline"
        )}>
          {device.riskScore}
        </div>
        <div className="flex-1 h-1 bg-white/5 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${device.riskScore * 10}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className={cn(
              "h-full rounded-full",
              isHighRisk ? "bg-white glow-white" : "bg-outline"
            )}
          />
        </div>
      </div>

      {/* Exposure */}
      <div className="flex justify-center gap-2">
        <div className="px-2 py-1 bg-black border border-white/10 rounded flex items-center gap-1.5 min-w-[70px] justify-center">
          <Lock className="w-3 h-3 text-outline" />
          <span className="text-[10px] font-mono text-white/70">{device.ports} Ports</span>
        </div>
        <div className="px-2 py-1 bg-black border border-white/10 rounded flex items-center gap-1.5 min-w-[70px] justify-center">
          <ShieldAlert className="w-3 h-3 text-outline" />
          <span className="text-[10px] font-mono text-white/70">{device.cves} CVEs</span>
        </div>
      </div>

      {/* Action */}
      <div className="flex justify-end pr-2">
        <button className={cn(
          "flex items-center gap-2 px-4 py-2 rounded text-[10px] font-display font-bold uppercase tracking-wider transition-all",
          device.isQuarantined 
            ? "bg-white text-black border border-white" 
            : "bg-transparent border border-white/20 text-outline hover:text-white hover:border-white"
        )}>
          {device.isQuarantined ? <Lock className="w-4 h-4 fill-current" /> : <Unlock className="w-4 h-4" />}
          {device.isQuarantined ? "Quarantined" : "Quarantine"}
        </button>
      </div>
    </motion.div>
  );
}
