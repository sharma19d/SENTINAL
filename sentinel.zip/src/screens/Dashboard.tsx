import React from 'react';
import { motion } from 'motion/react';
import { AlertCircle, CheckCircle, ShieldAlert, RefreshCw, Wifi, Shield, Router } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Dashboard() {
  return (
    <div className="p-10 flex flex-col gap-8">
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-3 px-4 py-2 bg-white/5 rounded border border-white/20 glow-white">
          <motion.div 
            animate={{ opacity: [1, 0.4, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-2 h-2 rounded-full bg-white" 
          />
          <span className="text-[11px] font-mono text-white uppercase tracking-widest">System Protected</span>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Left Column: Metrics & Activity */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-6">
          {/* Network Health Gauge */}
          <div className="void-card rounded-xl p-8 flex flex-col items-center justify-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent opacity-0 group-hover:opacity-10 transition-opacity" />
            <h2 className="text-[11px] font-display font-bold text-outline uppercase tracking-widest absolute top-6 left-6">Network Health</h2>
            
            <div className="w-40 h-40 mt-8 relative flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="45" fill="none" stroke="#222" strokeWidth="6" />
                <motion.circle 
                  initial={{ strokeDashoffset: 283 }}
                  animate={{ strokeDashoffset: 283 * 0.06 }}
                  transition={{ duration: 2, ease: "easeOut" }}
                  cx="50" cy="50" r="45" 
                  fill="none" 
                  stroke="white" 
                  strokeWidth="6" 
                  strokeDasharray="283"
                  className="drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-3xl font-mono text-white font-bold drop-shadow-[0_0_5px_rgba(255,255,255,0.5)] tracking-tighter">94%</span>
                <span className="text-[10px] font-display font-bold text-outline uppercase tracking-tighter mt-1">Optimal</span>
              </div>
            </div>
          </div>

          {/* Stats Container */}
          <div className="grid grid-cols-2 gap-6">
            <div className="glass-panel-heavy rounded-xl p-6 relative overflow-hidden border-2 border-white/40 ring-1 ring-white/10 glow-white">
              <div className="absolute -right-4 -top-4 w-16 h-16 bg-white/20 rounded-full blur-xl" />
              <h2 className="text-[10px] font-display font-bold text-white uppercase tracking-widest mb-2">Active Threats</h2>
              <div className="flex items-end gap-2">
                <span className="text-4xl font-sans font-extrabold text-white leading-none">03</span>
                <AlertCircle className="w-5 h-5 text-white mb-1" />
              </div>
              <div className="mt-3 flex items-center gap-1 text-white font-mono text-[10px]">
                <RefreshCw className="w-3 h-3" />
                <span>+1 from last hr</span>
              </div>
            </div>

            <div className="glass-panel rounded-xl p-6 border border-white/10 ring-1 ring-white/5">
              <h2 className="text-[10px] font-display font-bold text-outline uppercase tracking-widest mb-2">Protected Nodes</h2>
              <div className="flex items-end gap-2">
                <span className="text-4xl font-sans font-extrabold text-white leading-none tracking-tight">1,428</span>
              </div>
              <div className="mt-3 flex items-center gap-1 text-outline font-mono text-[10px]">
                <CheckCircle className="w-3 h-3" />
                <span>All Online</span>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="flex-1 glass-panel rounded-xl flex flex-col overflow-hidden min-h-[300px]">
            <div className="px-5 py-4 border-b border-white/5">
              <h2 className="text-[11px] font-display font-bold text-outline uppercase tracking-widest">Recent Activity</h2>
            </div>
            <div className="flex-1 overflow-y-auto overflow-x-hidden p-2 space-y-2">
              <ActivityItem 
                icon={<ShieldAlert className="w-4 h-4 text-white" />}
                title="Intrusion attempt blocked"
                detail="IP: 192.168.1.105 | Node-Beta"
                time="2m ago"
                isCritical
              />
              <ActivityItem 
                icon={<RefreshCw className="w-4 h-4 text-outline" />}
                title="Firewall rules updated"
                detail="Auto-deploy successful"
                time="15m ago"
              />
              <ActivityItem 
                icon={<Wifi className="w-4 h-4 text-white" />}
                title="New IoT device detected"
                detail="MAC: 00:1A:2B:3C:4D:5E"
                time="1h ago"
              />
              <ActivityItem 
                icon={<Shield className="w-4 h-4 text-outline" />}
                title="Daily scan completed"
                detail="0 vulnerabilities found"
                time="3h ago"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Network Map */}
        <div className="col-span-12 lg:col-span-8 void-card rounded-xl relative overflow-hidden flex flex-col group min-h-[500px]">
          <div className="absolute top-6 left-6 right-6 flex justify-between items-start z-10 pointer-events-none">
            <div>
              <h2 className="text-[11px] font-display font-bold text-white tracking-widest uppercase mb-1 drop-shadow-[0_0_5px_rgba(255,255,255,0.5)]">Network Topology</h2>
              <p className="text-[10px] font-mono text-outline">Real-time Node Map</p>
            </div>
          </div>

          <div className="absolute bottom-6 left-6 z-10 glass-panel p-3 rounded-lg border border-white/10 flex flex-col gap-2">
            <span className="text-[9px] font-display font-bold text-outline uppercase tracking-wider">Risk Score</span>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full border border-outline-variant" /><span className="text-[10px] font-mono text-outline uppercase">Low</span></div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-full border-2 border-white/40 bg-white/10" /><span className="text-[10px] font-mono text-white/70 uppercase">Med</span></div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-full bg-white glow-white" /><span className="text-[10px] font-mono text-white font-bold uppercase">High</span></div>
            </div>
          </div>

          {/* Grid Background */}
          <div className="absolute inset-0 pointer-events-none opacity-20" 
            style={{ 
              backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)', 
              backgroundSize: '40px 40px' 
            }} 
          />

          <div className="flex-1 w-full h-full relative flex items-center justify-center">
            {/* Animated SVG Lines */}
            <svg className="absolute inset-0 w-full h-full z-0 opacity-50">
              <motion.g
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1 }}
              >
                {[
                  { x2: "30%", y2: "20%" },
                  { x2: "70%", y2: "25%" },
                  { x2: "80%", y2: "60%" },
                  { x2: "40%", y2: "80%" },
                  { x2: "20%", y2: "60%" }
                ].map((pos, i) => (
                  <line 
                    key={i}
                    x1="50%" y1="50%" 
                    x2={pos.x2} y2={pos.y2} 
                    stroke="white" 
                    strokeWidth="1.5"
                    strokeDasharray="4 4"
                    strokeOpacity="0.2"
                  />
                ))}
                {/* Critical connection */}
                <motion.line 
                   animate={{ strokeDashoffset: [0, -10] }}
                   transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                   x1="70%" y1="25%" x2="85%" y2="15%" 
                   stroke="white" 
                   strokeWidth="2" 
                   strokeDasharray="4 4" 
                />
              </motion.g>
            </svg>

            {/* Central Node */}
            <motion.div 
               whileHover={{ scale: 1.1 }}
               className="relative z-10 w-16 h-16 rounded-full glass-panel-heavy p-1 border-2 border-white glow-white flex items-center justify-center shadow-[0_0_30px_rgba(255,255,255,0.2)]"
            >
              <Router className="w-8 h-8 text-white" />
            </motion.div>

            {/* Connected Nodes */}
            <Node x="30%" y="20%" label="IoT-Cam-01" risk="low" />
            <Node x="70%" y="25%" label="Smart-Lock-A" risk="medium" />
            <Node x="85%" y="15%" label="UNKNOWN-DEVICE" risk="high" isCritical />
            <Node x="80%" y="60%" label="Printer-Main" risk="low" />
            <Node x="40%" y="80%" label="Gateway-B" risk="low" />
            <Node x="20%" y="60%" label="Sensor-04" risk="low" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Node({ x, y, label, risk, isCritical }: { x: string, y: string, label: string, risk: 'low' | 'medium' | 'high', isCritical?: boolean }) {
  return (
    <motion.div 
      style={{ left: x, top: y }}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group cursor-pointer"
    >
      <div className={cn(
        "rounded-full border transition-all duration-300",
        risk === 'low' && "w-4 h-4 border-outline-variant bg-black group-hover:border-white",
        risk === 'medium' && "w-6 h-6 border-white/40 bg-white/10 group-hover:border-white group-hover:bg-white/20",
        risk === 'high' && "w-8 h-8 bg-white border-2 border-black glow-white ring-4 ring-white/10"
      )}>
        {isCritical && (
          <motion.div 
            animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute inset-0 rounded-full bg-white sm:scale-150 scale-125"
          />
        )}
      </div>
      <div className="mt-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap bg-black border border-white/20 px-2 py-1 rounded text-[10px] font-mono text-white/70 pointer-events-none">
        {label}
      </div>
    </motion.div>
  );
}

function ActivityItem({ icon, title, detail, time, isCritical }: { icon: React.ReactNode, title: string, detail: string, time: string, isCritical?: boolean }) {
  return (
    <div className={cn(
      "p-3 rounded border transition-all duration-200 flex gap-4 group cursor-pointer",
      isCritical 
        ? "bg-white/5 border-white/20 hover:bg-white/10" 
        : "bg-surface-container-low/30 border-white/5 hover:border-white/10 hover:bg-white/5"
    )}>
      <div className="mt-1">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className={cn("text-xs font-bold leading-tight truncate", isCritical ? "text-white" : "text-on-surface")}>{title}</p>
        <p className="text-[10px] font-mono text-outline mt-1 truncate uppercase tracking-tight">{detail}</p>
      </div>
      <span className="text-[10px] font-mono text-outline whitespace-nowrap">{time}</span>
    </div>
  );
}
