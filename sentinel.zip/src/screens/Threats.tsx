import React from 'react';
import { motion } from 'motion/react';
import { AlertCircle, ShieldOff, Search, CheckCircle2, Gavel, ShieldCheck } from 'lucide-react';
import { THREATS } from '../constants';
import { cn } from '../lib/utils';
import { Threat } from '../types';

export default function Threats() {
  return (
    <div className="p-10 flex flex-col gap-8 max-w-6xl mx-auto w-full">
      <div className="flex justify-between items-center bg-black/40 backdrop-blur-xl p-6 rounded-2xl border border-white/5 border-t-white/10">
        <div className="flex items-center gap-6">
          <div className="text-[11px] font-display font-bold text-outline tracking-[0.2em] uppercase">Sentinel</div>
          <div className="w-px h-6 bg-white/10" />
          <h2 className="text-3xl font-bold text-white tracking-tight leading-none">Live Threat Feed</h2>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="bg-white/5 border border-white/10 rounded-full px-4 py-2 flex items-center gap-3 w-64 group focus-within:border-white/30 transition-all">
            <Search className="w-4 h-4 text-outline group-focus-within:text-white" />
            <input 
              type="text" 
              placeholder="Filter vectors..." 
              className="bg-transparent border-none text-sm text-white placeholder:text-outline/50 focus:ring-0 p-0 w-full font-mono uppercase tracking-tight"
            />
          </div>
        </div>
      </div>

      <div className="relative mt-4">
        {/* Timeline Line */}
        <div className="absolute left-[24px] top-4 bottom-4 w-px bg-gradient-to-b from-white/30 via-white/10 to-transparent" />
        
        <div className="flex flex-col gap-10">
          {THREATS.map((threat, index) => (
            <ThreatCard key={threat.id} threat={threat} index={index} />
          ))}
        </div>
      </div>
    </div>
  );
}

const ThreatCard: React.FC<{ threat: Threat; index: number }> = ({ threat, index }) => {
  const isCritical = threat.severity >= 9;
  const isHigh = threat.severity >= 7 && threat.severity < 9;

  return (
    <motion.div 
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.1 }}
      className="relative pl-[60px]"
    >
      {/* Node */}
      <div className={cn(
        "absolute left-[19px] top-[24px] w-[11px] h-[11px] rounded-full z-10 ring-4 ring-black",
        isCritical ? "bg-white glow-white" : "bg-outline"
      )} />

      {/* Card Content */}
      <div className={cn(
        "relative rounded-2xl overflow-hidden transition-all duration-300",
        isCritical 
          ? "bg-black border border-white/30 shadow-[0_0_40px_rgba(255,255,255,0.05)]" 
          : "glass-panel-heavy border-white/10"
      )}>
        {/* Subtle white glow top edge for critical */}
        {isCritical && (
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/50 to-transparent" />
        )}

        <div className="p-8">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center gap-3">
              <span className={cn("text-[11px] font-mono leading-none tracking-tight uppercase", isCritical ? "text-white" : "text-outline")}>{threat.time}</span>
              <div className="w-1 h-1 bg-white/20 rounded-full" />
              <span className={cn("text-[11px] font-mono leading-none tracking-tight uppercase", isCritical ? "text-white" : "text-white/60")}>{threat.code}</span>
            </div>
            
            <div className={cn(
              "px-3 py-1.5 rounded flex items-center gap-2 border",
              isCritical ? "bg-white/10 border-white text-white" : "bg-white/5 border-white/20 text-white/80"
            )}>
              <AlertCircle className="w-3.5 h-3.5" />
              <span className="text-[10px] font-display font-bold uppercase tracking-widest leading-none">SEV {threat.severity.toString().padStart(2, '0')}</span>
            </div>
          </div>

          <div className="mb-8">
            <h3 className={cn("text-xl font-bold mb-2 tracking-tight", isCritical ? "text-white" : "text-on-surface")}>{threat.title}</h3>
            <p className="text-sm text-on-surface-variant leading-relaxed max-w-2xl">{threat.description}</p>
          </div>

          <div className="grid grid-cols-2 gap-6 mb-8 bg-white/[0.03] p-4 rounded-xl border border-white/5">
            <div>
              <p className="text-[10px] font-display font-bold text-outline uppercase tracking-widest mb-1.5">Source Vector</p>
              <p className={cn("text-sm font-mono tracking-tight", isCritical ? "text-white" : "text-white/80")}>
                {threat.source} <span className="text-outline text-xs italic">{threat.sourceDetail}</span>
              </p>
            </div>
            <div>
              <p className="text-[10px] font-display font-bold text-outline uppercase tracking-widest mb-1.5">Target Vector</p>
              <p className={cn("text-sm font-mono tracking-tight", isCritical ? "text-white" : "text-white/80")}>
                {threat.target} <span className="text-outline text-xs italic">{threat.targetDetail}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between pt-6 border-t border-white/10">
            <div className={cn("flex items-center gap-2", isCritical ? "text-white" : "text-outline")}>
              {index === 0 ? <ShieldOff className="w-4 h-4" /> : index === 1 ? <Gavel className="w-4 h-4" /> : <ShieldCheck className="w-4 h-4" />}
              <span className="text-[11px] font-mono uppercase tracking-wider">Action: {threat.action}</span>
            </div>
            
            <div className="flex gap-3">
              <button className="px-5 py-2 text-xs font-bold font-display uppercase tracking-wider text-white border border-white/20 rounded-lg hover:bg-white/10 transition-all">Acknowledge</button>
              <button 
                className={cn(
                  "px-5 py-2 text-xs font-bold font-display uppercase tracking-wider rounded-lg transition-all",
                  isCritical 
                    ? "bg-white text-black hover:bg-white/90 shadow-[0_0_15px_rgba(255,255,255,0.2)]" 
                    : "border border-white/20 text-white hover:bg-white/10"
                )}
              >
                {isCritical ? "Investigate" : "View Logs"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
